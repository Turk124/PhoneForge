# Phone Forge — Ultimate Designer

Android native app prototype built with Kotlin + Jetpack Compose.

## Included
- Expanded SoC catalog: Snapdragon, Dimensity, Apple A, Exynos, Tensor, Kirin, Unisoc and Phone Forge concept chips.
- Camera sensor/lens options, display, resolution, RAM/storage, battery/charging, chassis, cooling, connectivity, protection, biometrics, audio, microphones, haptics, sensors, screen glass and security.
- Adjustable camera megapixels, refresh rate, battery capacity, RAM, CPU clock target and peak brightness target.
- Approximate performance, heat, battery-life and parts-cost indicators.
- Saves the latest design report to app preferences and shares a text report through Android's share menu.

## Important
This is source code, not a prebuilt APK. Estimates are illustrative, not real benchmark measurements or verified component prices. Options labelled concept are fictional targets. Some real-chip specifications vary by device and manufacturer.

## Build on GitHub Actions
1. Upload the contents of this project to the root of a GitHub repository.
2. Open Actions and run **Build Phone Forge APK** (or push to `main`).
3. Download the `PhoneForge-debug-apk` artifact from the completed workflow.
4. Extract the artifact ZIP on Android and install `app-debug.apk`.
