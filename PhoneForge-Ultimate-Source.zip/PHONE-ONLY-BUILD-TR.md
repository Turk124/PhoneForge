# Phone Forge APK'yı yalnızca telefondan derleme

Bu ZIP kaynak kodudur, APK değildir. Android Studio yerine GitHub Actions ile APK oluşturabilirsin.

1. GitHub hesabına telefondaki tarayıcıdan giriş yap: https://github.com
2. Yeni bir repository oluştur. Örnek: `PhoneForge`. Kaynak kodunu paylaşmak istemiyorsan repository'yi Private tutabilirsin; GitHub Actions ücretsiz dakika/erişim kuralları hesabına göre değişebilir.
3. Bu ZIP'i telefonda aç. ZIP'in içindeki dosya ve klasörleri (özellikle `app`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`) repository'nin en üst düzeyine yükle. İçerikleri fazladan bir alt klasör içine koyma.
4. Repository'de **Actions** sekmesine gir. **Build Phone Forge APK** iş akışını seç ve **Run workflow** düğmesine bas. İlk derleme birkaç dakika sürebilir.
5. İşlem yeşil tik ile tamamlanınca çalıştırmayı aç ve **Artifacts** bölümünden `PhoneForge-debug-apk` dosyasını indir.
6. İnen ZIP'i çıkar. İçindeki `app-debug.apk` dosyasına dokunarak kur. Android isterse yalnızca kullandığın tarayıcı/dosya yöneticisi için bu kaynaktan yükleme iznini aç.

Hata çıkarsa Actions günlüğünün son 20–30 satırını paylaş.

Not: Bu işlem debug/test APK üretir; Play Store'a yüklemeye hazır release paketi değildir. ZIP'in kendisi APK değildir.
