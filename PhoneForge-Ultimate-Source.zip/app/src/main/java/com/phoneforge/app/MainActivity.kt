package com.phoneforge.app

import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val ink = Color(0xFF10131C)
private val panel = Color(0xFF1B2030)
private val cyan = Color(0xFF54E4F5)
private val purple = Color(0xFF9C7BFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PhoneForgeApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PhoneForgeApp() {
    val options = mapOf(
        "İşlemci / SoC" to listOf("Snapdragon 8 Elite Gen 5", "Snapdragon 8 Elite", "Snapdragon 8 Gen 3", "Snapdragon 8 Gen 2", "Snapdragon 8+ Gen 1", "Snapdragon 8 Gen 1", "Snapdragon 8s Gen 4", "Snapdragon 8s Gen 3", "Snapdragon 7+ Gen 3", "Snapdragon 7 Gen 4", "Snapdragon 7 Gen 3", "Snapdragon 7s Gen 3", "Snapdragon 6 Gen 4", "Snapdragon 6 Gen 3", "Snapdragon 6 Gen 1", "Snapdragon 4 Gen 2", "Dimensity 9500", "Dimensity 9400+", "Dimensity 9400", "Dimensity 9300+", "Dimensity 9300", "Dimensity 8500 konsept", "Dimensity 8400", "Dimensity 8300", "Dimensity 8350", "Dimensity 7400", "Dimensity 7300", "Dimensity 7200", "Dimensity 6400", "Dimensity 6300", "Apple A19 Pro", "Apple A19", "Apple A18 Pro", "Apple A18", "Apple A17 Pro", "Apple A16 Bionic", "Apple A15 Bionic", "Exynos 2600", "Exynos 2500", "Exynos 2400", "Exynos 2400e", "Exynos 1580", "Exynos 1480", "Exynos 1380", "Google Tensor G5", "Google Tensor G4", "Google Tensor G3", "Google Tensor G2", "Kirin 9020", "Kirin 9010", "Kirin 9000S", "Kirin 8000", "Unisoc T9100", "Unisoc T820", "Unisoc T760", "Unisoc T616", "Unisoc T606", "NOVA N1 özel SoC", "NOVA Titan X konsept SoC", "Phone Forge Gaming G1 konsept SoC", "Phone Forge Eco E1 konsept SoC"),
        "CPU çekirdek düzeni" to listOf("1+3+4 performans/verimlilik", "2+6 performans/verimlilik", "2+4+2 dengeli", "4 performans + 4 verimlilik", "8 performans çekirdeği konsepti", "12 çekirdek konsept tasarım"),
        "GPU" to listOf("Adreno 830", "Adreno 750", "Adreno 740", "Adreno 735", "Adreno 730", "Adreno orta seviye", "Mali-G1 Ultra konsept", "Immortalis-G925", "Immortalis-G720", "Mali-G615", "Apple GPU", "Xclipse 950", "Xclipse 940", "PowerVR", "Özel oyun GPU'su"),
        "NPU / Yapay zekâ" to listOf("Temel AI hızlandırıcı", "20 TOPS sınıfı", "40 TOPS sınıfı", "60 TOPS sınıfı", "100 TOPS konsept", "Özel yerel AI motoru"),
        "ISP / Görüntü işlemci" to listOf("Standart ISP", "Çift ISP", "Üçlü ISP", "AI destekli çoklu kamera ISP", "8K video ISP konsepti"),
        "Modem" to listOf("4G LTE modem", "5G Sub-6 modem", "5G mmWave + Sub-6", "5G Advanced konsept", "Uydu destekli modem konsepti"),
        "Ana kamera sensörü" to listOf("Sony LYT-808 1/1.4\"", "Sony LYT-900 1\"", "Sony IMX989 1\"", "Sony LYT-700", "Samsung HP9 200 MP", "Samsung HP2 200 MP", "Samsung GNK 50 MP", "Samsung JN5 50 MP", "OmniVision OV50H", "OmniVision OV50K", "OmniVision OV64B", "Özel 1 inç sensör"),
        "Ultra geniş kamera" to listOf("12 MP temel", "13 MP otomatik odaklama", "Sony 50 MP", "Samsung JN5 50 MP", "OmniVision 50 MP", "Ultra geniş yok"),
        "Telefoto / Periskop" to listOf("Yok", "3x optik telefoto 50 MP", "5x periskop 50 MP", "6x periskop 200 MP", "10x periskop 50 MP", "Değişken optik zoom"),
        "Ön kamera" to listOf("10 MP", "12 MP", "32 MP", "50 MP otomatik odaklama", "4K video odaklı 24 MP"),
        "Ekran" to listOf("6.1\" OLED 120 Hz", "6.3\" LTPO OLED 1-120 Hz", "6.7\" AMOLED 144 Hz", "6.8\" LTPO AMOLED 1-144 Hz", "6.9\" QHD+ LTPO 1-120 Hz", "6.5\" LCD 120 Hz", "Katlanabilir 7.8\" OLED"),
        "Çözünürlük" to listOf("FHD+", "1.5K", "QHD+", "4K deneysel"),
        "RAM" to listOf("4 GB LPDDR4X", "6 GB LPDDR5", "8 GB LPDDR5X", "12 GB LPDDR5X", "16 GB LPDDR5X", "24 GB LPDDR5X"),
        "Depolama" to listOf("64 GB UFS 2.2", "128 GB UFS 3.1", "256 GB UFS 4.0", "512 GB UFS 4.0", "1 TB UFS 4.1", "2 TB UFS 4.1", "4 TB konsept UFS"),
        "RAM teknolojisi" to listOf("LPDDR4X", "LPDDR5", "LPDDR5X", "LPDDR6 konsept"),
        "Depolama teknolojisi" to listOf("UFS 2.2", "UFS 3.1", "UFS 4.0", "UFS 4.1", "Yeni nesil UFS konsepti"),
        "Batarya" to listOf("3.000 mAh Li-ion", "4.000 mAh Li-ion", "5.000 mAh Li-ion", "5.500 mAh silikon-karbon", "6.000 mAh silikon-karbon", "7.000 mAh silikon-karbon", "8.000 mAh silikon-karbon", "10.000 mAh deneysel"),
        "Batarya teknolojisi" to listOf("Lityum iyon", "Lityum polimer", "Silikon-karbon", "Çift hücreli silikon-karbon", "Katı hâl batarya konsepti"),
        "Kablolu şarj" to listOf("10 W", "18 W", "25 W", "33 W", "45 W", "67 W", "90 W", "120 W", "150 W", "200 W konsept"),
        "Şarj standardı" to listOf("USB Power Delivery", "USB PD + PPS", "Üreticiye özel hızlı şarj", "Çoklu protokol hızlı şarj"),
        "Kablosuz şarj" to listOf("Yok", "5 W Qi", "15 W Qi", "25 W Qi2 sınıfı", "30 W", "50 W konsept"),
        "Wi-Fi" to listOf("Wi-Fi 5", "Wi-Fi 6", "Wi-Fi 6E", "Wi-Fi 7", "Wi-Fi 8 konsept"),
        "Bluetooth" to listOf("Bluetooth 5.0", "Bluetooth 5.2", "Bluetooth 5.3", "Bluetooth 5.4", "Yeni nesil Bluetooth konsepti"),
        "USB / Veri" to listOf("USB-C USB 2.0", "USB-C USB 3.2", "USB-C USB 4", "USB-C + DisplayPort", "USB-C yüksek hızlı konsept"),
        "Kasa malzemesi" to listOf("Polikarbonat", "Alüminyum çerçeve + cam", "Titanyum + cam", "Seramik + titanyum", "Geri dönüştürülmüş alüminyum", "Deri dokulu kompozit"),
        "Soğutma" to listOf("Standart grafit", "Büyük buhar odası", "Çift buhar odası", "Grafen + buhar odası", "Aktif mini fan", "Sıvı metal + buhar odası"),
        "Bağlantı" to listOf("4G + Wi-Fi 5", "5G + Wi-Fi 6", "5G + Wi-Fi 7", "5G Advanced + Wi-Fi 7", "Uydu SOS + 5G + Wi-Fi 7"),
        "Gövde koruması" to listOf("IP54", "IP67", "IP68", "IP69", "IP68 + askeri dayanım"),
        "Biyometrik" to listOf("Yan parmak izi", "Ekran içi optik", "Ekran içi ultrasonik", "3D yüz tanıma", "Ultrasonik + 3D yüz"),
        "Ses sistemi" to listOf("Tek hoparlör", "Stereo hoparlör", "Simetrik stereo", "Dolby Atmos hedefli stereo", "Üç hoparlör konsepti"),
        "Mikrofon" to listOf("2 mikrofon", "3 mikrofon", "4 mikrofon", "AI gürültü azaltmalı 4 mikrofon"),
        "Titreşim motoru" to listOf("Standart ERM", "X eksenli lineer motor", "Çift lineer motor", "Hassas haptik motor konsepti"),
        "Sensör paketi" to listOf("Temel sensör paketi", "Jiroskop + ivmeölçer + pusula", "Barometre + yakınlık + ışık", "Tam sensör paketi", "Gelişmiş renk sıcaklığı sensörü"),
        "Ekran koruması" to listOf("Standart cam", "Güçlendirilmiş cam", "Gorilla Glass sınıfı", "Seramik cam", "Safir cam konsepti"),
        "Güvenlik çipi" to listOf("Yazılımsal güvenlik", "Güvenli alan / TEE", "Ayrı güvenlik yongası", "Donanım güvenlik modülü konsepti"),
        "İşletim sistemi" to listOf("Android tabanlı", "Özel Android arayüzü", "Minimal hafif OS", "Oyun odaklı OS", "Geliştirici özel sistemi")
    )
    val defaults = remember { options.mapValues { it.value.first() }.toMutableMap() }
    var selected by remember { mutableStateOf(defaults.toMap()) }
    var brand by remember { mutableStateOf("NOVA") }
    var model by remember { mutableStateOf("Forge X1") }
    var megapixels by remember { mutableFloatStateOf(50f) }
    var refresh by remember { mutableFloatStateOf(120f) }
    var battery by remember { mutableFloatStateOf(5000f) }
    var ram by remember { mutableFloatStateOf(12f) }
    var cpuClock by remember { mutableFloatStateOf(3.2f) }
    var brightness by remember { mutableFloatStateOf(1500f) }
    var saved by remember { mutableStateOf(false) }
    val socIndex = options["İşlemci / SoC"]!!.indexOf(selected["İşlemci / SoC"]).coerceAtLeast(0)
    val performance = (58 + (14 - socIndex).coerceAtLeast(0) * 2.4 + ram * .55 + (if (selected["GPU"]!!.contains("üst")) 9 else 0) + (if (selected["Soğutma"]!!.contains("buhar")) 5 else 0)).toInt().coerceIn(25, 99)
    val heat = (35 + performance * .22 + (if (selected["Soğutma"]!!.contains("Standart")) 9 else -4) + (if (selected["Kablolu şarj"] == "150 W") 5 else 0)).toInt().coerceIn(28, 75)
    val batteryLife = (battery / 5000 * (1.0 + (if (selected["Ekran"]!!.contains("LTPO")) .16 else 0.0) - (refresh - 120).coerceAtLeast(0f) / 900 - performance / 500.0) * 24).toInt().coerceIn(5, 48)
    val cost = (1200 + performance * 48 + megapixels * 4 + battery * .22 + ram * 125 + refresh * 2.5 + cpuClock * 180 + brightness * .12 + selected.size * 75).toInt()
    val context = androidx.compose.ui.platform.LocalContext.current
    val report = "PHONE FORGE TASARIM RAPORU\n$brand $model\nPerformans tahmini: $performance/100\nIsı tahmini: $heat C\nPil tahmini: $batteryLife saat\nTahmini parça maliyeti: ₺$cost\nCPU saat hedefi: ${String.format(Locale.US, "%.1f", cpuClock)} GHz\nEkran parlaklığı hedefi: ${brightness.toInt()} nit\n" + selected.entries.joinToString("\n") { "${it.key}: ${it.value}" }

    MaterialTheme(colorScheme = darkColorScheme(primary = cyan, background = ink, surface = panel)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10131C), Color(0xFF17172B)))).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("PHONE FORGE", color = cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp); Text("Ultimate Designer", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold) }
                Surface(color = Color(0xFF24263A), shape = RoundedCornerShape(14.dp)) { Text("BETA 1.0", Modifier.padding(10.dp), color = purple, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ÖN TASARIM", color = cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                    Box(Modifier.width(170.dp).height(260.dp).background(Color(0xFF07090E), RoundedCornerShape(32.dp)).padding(8.dp)) {
                        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF303B61), Color(0xFF141927), Color(0xFF38265D))), RoundedCornerShape(26.dp))) {
                            Column(Modifier.align(Alignment.TopStart).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { repeat(3) { Box(Modifier.size(35.dp).background(Color(0xFF10131C), RoundedCornerShape(50)).padding(5.dp), contentAlignment = Alignment.Center) { Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(cyan, Color(0xFF27334C))), RoundedCornerShape(50))) } } }
                            Text("${brand.uppercase()}\n$model", Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                    OutlinedTextField(value = brand, onValueChange = { brand = it.take(18) }, label = { Text("Marka adı") }, singleLine = true)
                    OutlinedTextField(value = model, onValueChange = { model = it.take(24) }, label = { Text("Model adı") }, singleLine = true)
                    Text("Seçimlerin telefonun puanlarını ve maliyetini etkiler.", color = Color.LightGray, fontSize = 12.sp)
                }
            }
            Text("CANLI SİSTEM ANALİZİ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("Performans", "$performance/100", cyan, Modifier.weight(1f))
                Metric("Isı tahmini", "$heat°C", if (heat > 60) Color(0xFFFF887A) else purple, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("Pil tahmini", "$batteryLife saat", Color(0xFF9CE6A2), Modifier.weight(1f))
                Metric("Parça maliyeti", "₺${String.format(Locale("tr", "TR"), "%,d", cost)}", Color(0xFFFFD479), Modifier.weight(1f))
            }
            Card(colors = CardDefaults.cardColors(containerColor = panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("HASSAS AYARLAR", color = cyan, fontWeight = FontWeight.Bold)
                SliderLine("Ana kamera çözünürlüğü", megapixels, 12f, 200f, "${megapixels.toInt()} MP") { megapixels = it }
                SliderLine("Ekran yenileme hızı", refresh, 60f, 240f, "${refresh.toInt()} Hz") { refresh = it }
                SliderLine("Batarya kapasitesi", battery, 3000f, 10000f, "${battery.toInt()} mAh") { battery = it }
                SliderLine("RAM kapasitesi", ram, 4f, 24f, "${ram.toInt()} GB") { ram = it }
                SliderLine("CPU saat hızı hedefi", cpuClock, 1.5f, 4.5f, String.format(Locale.US, "%.1f GHz", cpuClock)) { cpuClock = it }
                SliderLine("Tepe parlaklık hedefi", brightness, 400f, 4000f, "${brightness.toInt()} nit") { brightness = it }
            } }
            Text("BİLEŞEN LABORATUVARI · ${options.size} KATEGORİ", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            options.forEach { (category, values) ->
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(category, color = cyan, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        var expanded by remember(category) { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                            OutlinedTextField(value = selected[category] ?: values.first(), onValueChange = {}, readOnly = true, modifier = Modifier.fillMaxWidth().menuAnchor(), label = { Text("Parça seç") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                values.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { selected = selected.toMutableMap().apply { put(category, item) }; expanded = false }) }
                            }
                        }
                    }
                }
            }
            Button(onClick = {
                context.getSharedPreferences("phone_forge", android.content.Context.MODE_PRIVATE).edit()
                    .putString("last_report", report).putString("brand", brand).putString("model", model).apply()
                saved = true
            }, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = cyan, contentColor = ink), shape = RoundedCornerShape(18.dp)) { Text("TASARIMI KAYDET  ✓", fontWeight = FontWeight.ExtraBold) }
            OutlinedButton(onClick = {
                val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "$brand $model - Phone Forge raporu"); putExtra(Intent.EXTRA_TEXT, report) }
                context.startActivity(Intent.createChooser(intent, "Tasarım raporunu paylaş"))
            }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("TEKNİK RAPORU PAYLAŞ / DIŞA AKTAR") }
            if (saved) {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF203B38))) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("TASARIM KAYDI HAZIR", color = Color(0xFF9CE6A2), fontWeight = FontWeight.Bold)
                    Text("$brand $model", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${selected["İşlemci / SoC"]} · ${ram.toInt()} GB RAM · ${battery.toInt()} mAh · ${megapixels.toInt()} MP", color = Color.LightGray)
                    Text("Bu tasarım cihazda son rapor olarak saklandı. Teknik raporu paylaş düğmesiyle metin olarak dışa aktarabilirsin.", color = Color.LightGray, fontSize = 12.sp)
                } }
            }
            Text("Phone Forge · Parça özellikleri ve analizler oyun içi yaklaşık değerlerdir.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 18.dp))
        }
    }
}

@Composable private fun Metric(title: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(title, color = Color.LightGray, fontSize = 11.sp); Text(value, color = accent, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold) } }
}

@Composable private fun SliderLine(label: String, value: Float, min: Float, max: Float, display: String, onChange: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f), color = Color.White, fontSize = 12.sp); Text(display, color = cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp) }; Slider(value = value, onValueChange = onChange, valueRange = min..max, colors = SliderDefaults.colors(thumbColor = cyan, activeTrackColor = cyan)) }
}
